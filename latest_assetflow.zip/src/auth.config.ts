import Google from "next-auth/providers/google";
import Credentials from "next-auth/providers/credentials";
import type { NextAuthConfig } from "next-auth";

import { getRequiredRole } from "@/config/route-access";
import type { Role } from "@/types/role";

export default {
  providers: [Google, Credentials({ credentials: {} })],
  pages: {
    signIn: "/login",
  },
  session: {
    strategy: "jwt",
  },
  callbacks: {
    authorized({ auth, request }) {
      const isLoggedIn = !!auth?.user;
      const pathname = request.nextUrl.pathname;
      const requiredRole = getRequiredRole(pathname);

      // Onboarding page is always reachable by any logged-in user.
      if (pathname.startsWith("/onboarding")) {
        return isLoggedIn;
      }

      // Public and unmatched routes.
      if (requiredRole === null) return true;

      if (!isLoggedIn) return false;

      // A user with onboardingRequired must complete onboarding before
      // accessing any dashboard route. The proxy redirects them to
      // /onboarding — the full server-side guard in the dashboard
      // layout also enforces this independently.
      const needsOnboarding = (auth as unknown as { user?: { onboardingRequired?: boolean } })
        ?.user?.onboardingRequired === true;

      if (needsOnboarding) {
        // Allow /login so they can switch accounts; block everything else.
        if (pathname === "/login") return true;
        return false;
      }

      if (requiredRole === "both") return true;

      return auth.user.role === requiredRole;
    },

    async session({ session, token }) {
      if (token) {
        session.user.id = token.id as string;
        session.user.role = token.role as Role;
        session.user.onboardingRequired = (token.onboardingRequired ?? false) as boolean;
      }
      return session;
    },
  },
} satisfies NextAuthConfig;
